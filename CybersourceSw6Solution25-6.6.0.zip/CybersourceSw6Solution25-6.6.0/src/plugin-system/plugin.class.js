export default class Plugin
{    
}
