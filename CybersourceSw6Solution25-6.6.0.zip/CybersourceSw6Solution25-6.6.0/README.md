# CyberSource for Shopware6 plugin
CyberSource for Shopware6 offers various payment methods which can be easily integrated into your Shopware web shop by using our plugin. CyberSource for Shopware6 accept all the major payment methods.

### Supported payment methods
- Credit card


## Requirements
- Shopware >= 6.5.0.0
- [CyberSource Account](https://developer.cybersource.com/api/developer-guides/dita-gettingstarted/registration.html)

## Documentation
Please find the relevant documentation for
 - [How to start with CyberSource](https://www.cybersource.com/en/developers.html)

## For developers

### Integration
The plugin integrates card components (Secured Fields) using CyberSource checkout for all card payments.

### Installation guide

#### For production
- Purchase the plugin from the [Shopware Store](https://store.shopware.com/).
- Log in to your Shopware back end.
- Go to Extensions > Store
- Find the CyberSource for Shopware6 plugin, and select Download.
- Go to Extensions > My extensions.
- Find the CyberSource for Shopware6 plugin, and select the action button (...) > Install.
- This adds all supported payment methods to your Shopware instance.
- Turn on the Activate toggle.

The plugin is now ready to be configured.

#### For development
- Upload the plugin repository into the `custom/plugins` folder in your Shopware installation.
- Inside the plugin directory run `composer install`
- Go to the plugin manager and install/activate the plugin.
- Run the following commands inside the Shopware folder:
    > `./psh.phar administration:build`

    > `./psh.phar storefront:build`

This will automatically generate all files required for the plugin to work correctly

# Support
If you have a feature request or spotted a bug or a technical problem, create a GitHub issue.
For creating a Pull Request follow our standard.
[Pull Request Template](.github/PULL_REQUEST_TEMPLATE.md)

## Gitflow & Release Flow   
-  A development branch is created from the `master`
-  Feature branches are created from `development`
-  When a feature is complete it is merged into the `development` branch  
-  Bugfix branches are created from `development`
-  When bug fixes are done  it is merged into the `development` branch 
-  Release branch is created from `development`
-  When the release branch is done it is merged into `development` and `master`  
-  If an issue in `master` is detected a hotfix branch is created from `master`  
-  When the hotfix is complete it is merged to both `development` and `master`

## Versioning
We are managing plugin versioning for managing our code. [click here](VERSIONING.md) for more details.

# License
CyberSource for Shopware6 license. For more information, see the [LICENSE file](LICENSE).
